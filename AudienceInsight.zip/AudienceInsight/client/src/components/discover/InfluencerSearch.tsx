import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, Plus, Users, CheckCircle } from "lucide-react";
import type { Influencer } from "@shared/schema";

export default function InfluencerSearch() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSize, setSelectedSize] = useState("");

  const { data: influencers, isLoading } = useQuery({
    queryKey: ["/api/influencers", { 
      search: searchQuery,
      category: selectedCategory,
      limit: 20 
    }],
  });

  const formatFollowers = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    }
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  const getInfluencerSize = (followers: number) => {
    if (followers >= 1000000) return "Mega";
    if (followers >= 100000) return "Macro";
    if (followers >= 10000) return "Micro";
    return "Nano";
  };

  const categories = [
    "Fashion",
    "Beauty",
    "Technology",
    "Fitness",
    "Food",
    "Travel",
    "Lifestyle",
    "Business",
  ];

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="w-5 h-5 mr-2" />
            Discover Influencers
          </CardTitle>
          <CardDescription>
            Find the perfect influencers for your brand and campaigns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by name, category, or keywords..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category.toLowerCase()}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={selectedSize} onValueChange={setSelectedSize}>
                <SelectTrigger>
                  <SelectValue placeholder="All Sizes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Sizes</SelectItem>
                  <SelectItem value="nano">Nano (1K-10K)</SelectItem>
                  <SelectItem value="micro">Micro (10K-100K)</SelectItem>
                  <SelectItem value="macro">Macro (100K-1M)</SelectItem>
                  <SelectItem value="mega">Mega (1M+)</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Advanced Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <Card>
        <CardHeader>
          <CardTitle>Search Results</CardTitle>
          <CardDescription>
            {isLoading 
              ? "Searching..." 
              : `Found ${influencers?.length || 0} influencers`
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="border border-slate-200 rounded-lg p-4 animate-pulse">
                  <div className="flex items-start space-x-3 mb-3">
                    <div className="w-12 h-12 bg-slate-200 rounded-full"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-3 bg-slate-200 rounded"></div>
                    <div className="h-3 bg-slate-200 rounded w-2/3"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : influencers?.length === 0 ? (
            <div className="text-center py-12">
              <Users className="mx-auto h-12 w-12 text-slate-400 mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No influencers found</h3>
              <p className="text-slate-600">
                Try adjusting your search criteria or browse all influencers.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {influencers?.map((influencer: Influencer) => (
                <div key={influencer.id} className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start space-x-3 mb-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={influencer.profileImageUrl || undefined} />
                      <AvatarFallback>
                        {influencer.name?.charAt(0)?.toUpperCase() || "I"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <h4 className="font-medium text-slate-900 truncate">
                          {influencer.name}
                        </h4>
                        {influencer.verified && (
                          <CheckCircle className="w-4 h-4 text-blue-500" />
                        )}
                      </div>
                      <p className="text-sm text-slate-600 truncate">
                        @{influencer.username}
                      </p>
                    </div>
                    <Button size="sm" variant="outline">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="space-y-2 mb-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-600">Followers:</span>
                      <span className="font-medium">
                        {formatFollowers(influencer.followerCount || 0)}
                      </span>
                    </div>
                    
                    {influencer.engagementRate && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-600">Engagement:</span>
                        <span className="font-medium">
                          {Number(influencer.engagementRate).toFixed(1)}%
                        </span>
                      </div>
                    )}
                    
                    {influencer.averageRate && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-600">Rate:</span>
                        <span className="font-medium">
                          ${Number(influencer.averageRate).toLocaleString()}/post
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mb-3">
                    <Badge variant="outline" className="text-xs">
                      {getInfluencerSize(influencer.followerCount || 0)}
                    </Badge>
                    {influencer.categories?.slice(0, 2).map((category) => (
                      <Badge key={category} variant="secondary" className="text-xs">
                        {category}
                      </Badge>
                    ))}
                  </div>
                  
                  {influencer.bio && (
                    <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                      {influencer.bio}
                    </p>
                  )}
                  
                  <Button className="w-full" size="sm">
                    View Profile
                  </Button>
                </div>
              ))}
            </div>
          )}
          
          {influencers && influencers.length > 0 && (
            <div className="mt-6 text-center">
              <Button variant="outline">
                Load More Results
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
