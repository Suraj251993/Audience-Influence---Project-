import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Users, DollarSign, Eye } from "lucide-react";

interface Metrics {
  totalReach: number;
  roi: string;
  activeInfluencers: number;
  activeCampaigns: number;
}

export default function MetricsCards() {
  const { data: metrics, isLoading } = useQuery<Metrics>({
    queryKey: ["/api/dashboard/metrics"],
    retry: false,
  });

  const metricsData = [
    {
      title: "Total Reach",
      value: metrics ? `${(metrics.totalReach / 1000000).toFixed(1)}M` : "0",
      icon: Eye,
      color: "bg-primary-100 text-primary-600",
      trend: "+12.5%",
    },
    {
      title: "Campaign ROI",
      value: metrics ? `${Math.round(parseFloat(metrics.roi) * 100)}%` : "0%",
      icon: DollarSign,
      color: "bg-emerald-100 text-emerald-600",
      trend: "+8.2%",
    },
    {
      title: "Active Influencers",
      value: metrics?.activeInfluencers?.toString() || "0",
      icon: Users,
      color: "bg-secondary-100 text-secondary-600",
      trend: "+23",
    },
    {
      title: "Active Campaigns",
      value: metrics?.activeCampaigns?.toString() || "0",
      icon: TrendingUp,
      color: "bg-amber-100 text-amber-600",
      trend: "+3",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-slate-200 rounded-lg"></div>
                <div className="ml-5 w-0 flex-1">
                  <div className="h-4 bg-slate-200 rounded w-24 mb-2"></div>
                  <div className="h-6 bg-slate-200 rounded w-16"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
      {metricsData.map((metric, index) => (
        <Card key={index}>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${metric.color}`}>
                  <metric.icon className="w-5 h-5" />
                </div>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">{metric.title}</dt>
                  <dd className="text-lg font-semibold text-slate-900">{metric.value}</dd>
                </dl>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center text-sm">
                <span className="text-emerald-600 font-medium">{metric.trend}</span>
                <span className="text-slate-500 ml-1">from last month</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
