import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { Influencer } from "@shared/schema";

type TopPerformer = Influencer & { roi: string; reach: number };

export default function TopPerformers() {
  const { data: topPerformers, isLoading } = useQuery<TopPerformer[]>({
    queryKey: ["/api/influencers/top-performers", { limit: 5 }],
    retry: false,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Top Performers</CardTitle>
          <p className="text-sm text-slate-500">Highest ROI influencers this month</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4 animate-pulse">
                <div className="h-10 w-10 bg-slate-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-slate-200 rounded w-24 mb-1"></div>
                  <div className="h-3 bg-slate-200 rounded w-16"></div>
                </div>
                <div className="text-right">
                  <div className="h-4 bg-slate-200 rounded w-16 mb-1"></div>
                  <div className="h-3 bg-slate-200 rounded w-12"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Top Performers</CardTitle>
            <p className="text-sm text-slate-500">Highest ROI influencers this month</p>
          </div>
          <Button variant="ghost" size="sm">
            View all
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {topPerformers && topPerformers.length > 0 ? (
            topPerformers.map((influencer) => (
              <div key={influencer.id} className="flex items-center space-x-4">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={influencer.profileImageUrl || undefined} />
                  <AvatarFallback>
                    {influencer.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">{influencer.name}</p>
                  <p className="text-sm text-slate-500 truncate">{influencer.niche}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">
                    {Math.round(parseFloat(influencer.roi) * 100)}% ROI
                  </p>
                  <p className="text-sm text-slate-500">
                    {influencer.reach ? `${(influencer.reach / 1000).toFixed(1)}K reach` : 'No data'}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-slate-500">No performance data available</p>
            </div>
          )}
        </div>
        <div className="mt-6">
          <Button variant="outline" className="w-full" size="sm">
            View All Influencers
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
