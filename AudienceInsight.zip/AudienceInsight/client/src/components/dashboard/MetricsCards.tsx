import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card";
import { TrendingUp, Users, BarChart3, Eye } from "lucide-react";

export default function MetricsCards() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + "M";
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + "K";
    }
    return num.toString();
  };

  const metricCards = [
    {
      title: "Total Reach",
      value: metrics?.totalReach || 0,
      icon: Eye,
      color: "bg-primary/10 text-primary",
      change: "+12.5%",
    },
    {
      title: "Campaign ROI",
      value: `${metrics?.roi || 0}%`,
      icon: TrendingUp,
      color: "bg-emerald-100 text-emerald-600",
      change: "+8.2%",
    },
    {
      title: "Active Influencers",
      value: metrics?.activeInfluencers || 0,
      icon: Users,
      color: "bg-secondary/10 text-secondary",
      change: "+23",
    },
    {
      title: "Active Campaigns",
      value: metrics?.activeCampaigns || 0,
      icon: BarChart3,
      color: "bg-amber-100 text-amber-600",
      change: "+3",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="w-8 h-8 bg-slate-200 rounded-lg"></div>
                <div className="h-4 bg-slate-200 rounded w-16"></div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-slate-200 rounded w-20 mb-2"></div>
              <div className="h-3 bg-slate-200 rounded w-24"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metricCards.map((metric, index) => {
        const Icon = metric.icon;
        
        return (
          <Card key={index}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${metric.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-xs text-emerald-600 font-medium">
                  {metric.change}
                </span>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">
                {typeof metric.value === 'number' ? formatNumber(metric.value) : metric.value}
              </div>
              <CardDescription>{metric.title}</CardDescription>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
