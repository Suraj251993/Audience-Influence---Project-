import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users } from "lucide-react";
import { Link } from "wouter";

export default function TopInfluencers() {
  const { data: topInfluencers, isLoading } = useQuery({
    queryKey: ["/api/dashboard/top-influencers"],
  });

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + "M";
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + "K";
    }
    return num.toString();
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Top Performers</CardTitle>
            <CardDescription>Highest ROI influencers this month</CardDescription>
          </div>
          <Link href="/discover">
            <a className="text-sm text-primary hover:underline">View all</a>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4 animate-pulse">
                <div className="w-10 h-10 bg-slate-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                </div>
                <div className="text-right">
                  <div className="h-4 bg-slate-200 rounded w-16 mb-2"></div>
                  <div className="h-3 bg-slate-200 rounded w-12"></div>
                </div>
              </div>
            ))}
          </div>
        ) : topInfluencers?.length === 0 ? (
          <div className="text-center py-8">
            <Users className="mx-auto h-12 w-12 text-slate-400 mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No influencers yet</h3>
            <p className="text-slate-600 mb-4">
              Start collaborating with influencers to see top performers here.
            </p>
            <Link href="/discover">
              <Button variant="outline">Discover Influencers</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {topInfluencers?.map((influencer: any) => (
              <div key={influencer.id} className="flex items-center space-x-4">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={influencer.profileImageUrl || undefined} />
                  <AvatarFallback>
                    {influencer.name?.charAt(0)?.toUpperCase() || "I"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">
                    {influencer.name}
                  </p>
                  <p className="text-sm text-slate-500 truncate">
                    {influencer.categories?.[0] || "Influencer"}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">
                    {influencer.roi}% ROI
                  </p>
                  <p className="text-sm text-slate-500">
                    {formatNumber(influencer.reach)} reach
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
