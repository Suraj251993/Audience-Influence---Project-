import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Filter, BarChart3 } from "lucide-react";
import { Link } from "wouter";
import type { Campaign } from "@shared/schema";

export default function RecentCampaigns() {
  const { data: campaigns, isLoading } = useQuery({
    queryKey: ["/api/campaigns", { limit: 5 }],
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      draft: "secondary",
      planning: "outline",
      active: "default",
      completed: "secondary",
      cancelled: "destructive",
    } as const;

    const colors = {
      draft: "bg-gray-100 text-gray-800",
      planning: "bg-blue-100 text-blue-800",
      active: "bg-emerald-100 text-emerald-800",
      completed: "bg-gray-100 text-gray-800",
      cancelled: "bg-red-100 text-red-800",
    } as const;

    return (
      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${colors[status as keyof typeof colors] || colors.draft}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Recent Campaigns</CardTitle>
            <CardDescription>Track and manage your active marketing campaigns</CardDescription>
          </div>
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="border border-slate-200 rounded-lg p-4 animate-pulse">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                  </div>
                  <div className="h-6 bg-slate-200 rounded w-16"></div>
                </div>
                <div className="flex items-center justify-between text-sm mb-3">
                  <div className="h-3 bg-slate-200 rounded w-1/3"></div>
                  <div className="h-3 bg-slate-200 rounded w-1/4"></div>
                </div>
                <div className="bg-slate-200 rounded-full h-2 mb-1"></div>
                <div className="h-3 bg-slate-200 rounded w-1/4"></div>
              </div>
            ))}
          </div>
        ) : campaigns?.length === 0 ? (
          <div className="text-center py-8">
            <BarChart3 className="mx-auto h-12 w-12 text-slate-400 mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No campaigns yet</h3>
            <p className="text-slate-600 mb-4">
              Create your first campaign to start collaborating with influencers.
            </p>
            <Link href="/campaigns">
              <Button>Create Campaign</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {campaigns?.slice(0, 5).map((campaign: Campaign) => (
              <div key={campaign.id} className="border border-slate-200 rounded-lg p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-medium text-slate-900">{campaign.name}</h4>
                    <p className="text-sm text-slate-600">{campaign.category}</p>
                  </div>
                  {getStatusBadge(campaign.status)}
                </div>
                
                <div className="flex items-center justify-between text-sm text-slate-600 mb-3">
                  <span>Budget: {formatCurrency(Number(campaign.budget))}</span>
                  <span>
                    {campaign.endDate 
                      ? `Ends ${new Date(campaign.endDate).toLocaleDateString()}`
                      : "No end date set"
                    }
                  </span>
                </div>
                
                {campaign.status === 'active' && (
                  <>
                    <div className="bg-slate-100 rounded-full h-2 mb-1">
                      <div 
                        className="bg-primary rounded-full h-2 transition-all duration-300" 
                        style={{ width: '68%' }}
                      ></div>
                    </div>
                    <p className="text-xs text-slate-600">68% complete</p>
                  </>
                )}
              </div>
            ))}
            
            {campaigns?.length > 5 && (
              <div className="text-center pt-4">
                <Link href="/campaigns">
                  <Button variant="outline">View All Campaigns</Button>
                </Link>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
