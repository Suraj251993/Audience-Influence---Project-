import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { BarChart3, Users, Target, TrendingUp, Handshake } from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: BarChart3 },
  { name: "Discover", href: "/discover", icon: Users },
  { name: "Campaigns", href: "/campaigns", icon: Target },
  { name: "Analytics", href: "/analytics", icon: TrendingUp },
  { name: "Collabs", href: "/collaborations", icon: Handshake },
];

export default function MobileNav() {
  const [location] = useLocation();

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-4 py-2">
      <div className="flex items-center justify-around">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <a
                className={cn(
                  "flex flex-col items-center space-y-1 py-2 px-3 rounded-lg",
                  isActive
                    ? "text-blue-600"
                    : "text-slate-400 hover:text-slate-600"
                )}
              >
                <item.icon className="h-5 w-5" />
                <span className="text-xs font-medium">{item.name}</span>
              </a>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
