import { Link, useLocation } from "wouter";
import { 
  Home, 
  Search, 
  BarChart3, 
  Users, 
  Handshake,
  Megaphone 
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Discover Influencers", href: "/discover", icon: Search },
  { name: "Campaigns", href: "/campaigns", icon: BarChart3 },
  { name: "Collaborations", href: "/collaborations", icon: Handshake },
  { name: "Analytics", href: "/analytics", icon: Users },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0">
      <div className="flex flex-col flex-grow bg-white border-r border-slate-200 pt-5 pb-4 overflow-y-auto">
        <div className="flex items-center flex-shrink-0 px-4">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <Megaphone className="w-5 h-5 text-white" />
            </div>
            <h1 className="ml-3 text-xl font-bold text-slate-900">Audience Influence</h1>
          </div>
        </div>
        
        <nav className="mt-8 flex-grow flex flex-col">
          <div className="flex-grow">
            <div className="px-2 space-y-1">
              {navigation.map((item) => {
                const isActive = location === item.href;
                const Icon = item.icon;
                
                return (
                  <Link key={item.name} href={item.href}>
                    <a
                      className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
                        isActive
                          ? "bg-primary/10 text-primary border-r-2 border-primary"
                          : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                      }`}
                    >
                      <Icon
                        className={`mr-3 flex-shrink-0 h-6 w-6 ${
                          isActive ? "text-primary" : "text-slate-400"
                        }`}
                      />
                      {item.name}
                    </a>
                  </Link>
                );
              })}
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
}
