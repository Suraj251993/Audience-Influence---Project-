import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Search } from "lucide-react";

interface SearchFiltersProps {
  search: string;
  filters: {
    niche: string;
    minFollowers?: number;
    maxFollowers?: number;
  };
  onSearchChange: (search: string) => void;
  onFiltersChange: (filters: any) => void;
}

export default function SearchFilters({
  search,
  filters,
  onSearchChange,
  onFiltersChange,
}: SearchFiltersProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search by name, category, or keywords..."
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Select
              value={filters.niche}
              onValueChange={(value) => onFiltersChange({ ...filters, niche: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Categories</SelectItem>
                <SelectItem value="fashion">Fashion</SelectItem>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="beauty">Beauty</SelectItem>
                <SelectItem value="fitness">Fitness</SelectItem>
                <SelectItem value="food">Food</SelectItem>
                <SelectItem value="travel">Travel</SelectItem>
                <SelectItem value="lifestyle">Lifestyle</SelectItem>
              </SelectContent>
            </Select>
            
            <Select
              onValueChange={(value) => {
                const [min, max] = value.split('-').map(v => v === 'inf' ? undefined : parseInt(v));
                onFiltersChange({ ...filters, minFollowers: min, maxFollowers: max });
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="All Sizes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Sizes</SelectItem>
                <SelectItem value="1000-10000">Nano (1K-10K)</SelectItem>
                <SelectItem value="10000-100000">Micro (10K-100K)</SelectItem>
                <SelectItem value="100000-1000000">Macro (100K-1M)</SelectItem>
                <SelectItem value="1000000-inf">Mega (1M+)</SelectItem>
              </SelectContent>
            </Select>
            
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Engagement Rate" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Any Engagement</SelectItem>
                <SelectItem value="0-2">Low (0-2%)</SelectItem>
                <SelectItem value="2-5">Medium (2-5%)</SelectItem>
                <SelectItem value="5-10">High (5-10%)</SelectItem>
                <SelectItem value="10-inf">Very High (10%+)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
