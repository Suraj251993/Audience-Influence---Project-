import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, TrendingUp, DollarSign, CheckCircle } from "lucide-react";
import type { Influencer } from "@shared/schema";

interface InfluencerCardProps {
  influencer: Influencer;
}

export default function InfluencerCard({ influencer }: InfluencerCardProps) {
  const formatFollowers = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <Avatar className="h-16 w-16">
            <AvatarImage src={influencer.profileImageUrl || undefined} />
            <AvatarFallback className="text-lg">
              {influencer.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-1">
              <h3 className="text-lg font-semibold text-slate-900 truncate">
                {influencer.name}
              </h3>
              {influencer.isVerified && (
                <CheckCircle className="h-4 w-4 text-blue-500" />
              )}
            </div>
            
            <Badge variant="secondary" className="mb-3">
              {influencer.niche}
            </Badge>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center text-slate-600">
                <Users className="h-4 w-4 mr-1" />
                {formatFollowers(influencer.followers)} followers
              </div>
              <div className="flex items-center text-slate-600">
                <TrendingUp className="h-4 w-4 mr-1" />
                {parseFloat(influencer.engagementRate).toFixed(1)}% engagement
              </div>
            </div>
            
            <div className="mt-3 text-sm text-slate-600">
              <div className="flex items-center">
                <DollarSign className="h-4 w-4 mr-1" />
                ${parseFloat(influencer.averagePostCost).toLocaleString()}/post
              </div>
            </div>
            
            {influencer.bio && (
              <p className="mt-3 text-sm text-slate-600 line-clamp-2">
                {influencer.bio}
              </p>
            )}
          </div>
        </div>
        
        <div className="mt-4 pt-4 border-t border-slate-200 flex space-x-2">
          <Button variant="outline" size="sm" className="flex-1">
            View Profile
          </Button>
          <Button size="sm" className="flex-1">
            Add to Campaign
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
