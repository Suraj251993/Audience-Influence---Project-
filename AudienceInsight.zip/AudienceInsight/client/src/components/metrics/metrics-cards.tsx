import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, Users, DollarSign, Eye } from "lucide-react";

export default function MetricsCards() {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
    retry: false,
  });

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(0)}K`;
    }
    return num.toString();
  };

  const metricCards = [
    {
      title: "Total Reach",
      value: metrics?.totalReach || 2400000,
      icon: Eye,
      color: "bg-blue-100",
      iconColor: "text-blue-600",
      change: "+12.5%",
    },
    {
      title: "Campaign ROI",
      value: metrics?.averageRoi ? `${metrics.averageRoi.toFixed(0)}%` : "324%",
      icon: DollarSign,
      color: "bg-emerald-100", 
      iconColor: "text-emerald-600",
      change: "+8.2%",
    },
    {
      title: "Active Influencers",
      value: metrics?.activeInfluencers || 147,
      icon: Users,
      color: "bg-purple-100",
      iconColor: "text-purple-600",
      change: "+23",
    },
    {
      title: "Active Campaigns",
      value: metrics?.activeCampaigns || 12,
      icon: TrendingUp,
      color: "bg-orange-100",
      iconColor: "text-orange-600",
      change: "+3",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metricCards.map((metric, index) => (
        <Card key={index} className="shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${metric.color} rounded-lg flex items-center justify-center`}>
                <metric.icon className={`w-6 h-6 ${metric.iconColor}`} />
              </div>
              <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">
                {metric.change}
              </Badge>
            </div>
            
            {isLoading ? (
              <>
                <Skeleton className="h-8 w-16 mb-2" />
                <Skeleton className="h-4 w-24" />
              </>
            ) : (
              <>
                <h3 className="text-2xl font-bold text-slate-900 mb-1">
                  {typeof metric.value === "number" ? formatNumber(metric.value) : metric.value}
                </h3>
                <p className="text-slate-600 text-sm">{metric.title}</p>
              </>
            )}
            
            <p className="text-xs text-slate-500 mt-2">vs. last month</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
