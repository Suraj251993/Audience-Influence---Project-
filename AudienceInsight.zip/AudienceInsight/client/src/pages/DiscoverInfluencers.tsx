import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import InfluencerCard from "@/components/InfluencerCard";
import { Search, Filter, SlidersHorizontal } from "lucide-react";

export default function DiscoverInfluencers() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [followerRange, setFollowerRange] = useState("");
  const [page, setPage] = useState(0);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const buildQueryParams = () => {
    const params = new URLSearchParams();
    if (search) params.append("search", search);
    if (category) params.append("category", category);
    if (followerRange) {
      const [min, max] = followerRange.split("-");
      if (min) params.append("minFollowers", min);
      if (max && max !== "plus") params.append("maxFollowers", max);
    }
    params.append("limit", "20");
    params.append("offset", (page * 20).toString());
    return params.toString();
  };

  const { data: influencers, isLoading: influencersLoading, error } = useQuery({
    queryKey: ["/api/influencers", search, category, followerRange, page],
    queryFn: async () => {
      const params = buildQueryParams();
      const response = await fetch(`/api/influencers?${params}`, {
        credentials: "include",
      });
      if (!response.ok) {
        const text = await response.text();
        throw new Error(`${response.status}: ${text}`);
      }
      return response.json();
    },
    retry: false,
  });

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [error, toast]);

  const handleSearch = () => {
    setPage(0); // Reset to first page when searching
  };

  const handleResetFilters = () => {
    setSearch("");
    setCategory("");
    setFollowerRange("");
    setPage(0);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-200 rounded w-1/3"></div>
          <div className="h-12 bg-slate-200 rounded"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-64 bg-slate-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold leading-7 text-slate-900 sm:text-3xl mb-2">
          Discover Influencers
        </h2>
        <p className="text-sm text-slate-500">
          Find the perfect creators for your brand with advanced filtering and search
        </p>
      </div>

      {/* Search and Filters */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="h-5 w-5 mr-2" />
            Search & Filter
          </CardTitle>
          <CardDescription>
            Narrow down your search to find the most relevant influencers
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Search Input */}
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search by name, category, or keywords..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
              </div>
              <Button onClick={handleSearch} className="bg-primary-600 hover:bg-primary-700">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </div>

            {/* Filters */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-slate-700 mb-2 block">Category</label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Categories</SelectItem>
                    <SelectItem value="fashion">Fashion & Lifestyle</SelectItem>
                    <SelectItem value="tech">Technology</SelectItem>
                    <SelectItem value="fitness">Health & Fitness</SelectItem>
                    <SelectItem value="food">Food & Cooking</SelectItem>
                    <SelectItem value="travel">Travel & Adventure</SelectItem>
                    <SelectItem value="beauty">Beauty & Skincare</SelectItem>
                    <SelectItem value="gaming">Gaming</SelectItem>
                    <SelectItem value="business">Business & Finance</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-slate-700 mb-2 block">Follower Count</label>
                <Select value={followerRange} onValueChange={setFollowerRange}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Sizes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Sizes</SelectItem>
                    <SelectItem value="1000-10000">Nano (1K-10K)</SelectItem>
                    <SelectItem value="10000-100000">Micro (10K-100K)</SelectItem>
                    <SelectItem value="100000-1000000">Macro (100K-1M)</SelectItem>
                    <SelectItem value="1000000-plus">Mega (1M+)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button variant="outline" onClick={handleResetFilters} className="w-full">
                  <SlidersHorizontal className="h-4 w-4 mr-2" />
                  Reset Filters
                </Button>
              </div>
            </div>

            {/* Active Filters */}
            {(search || category || followerRange) && (
              <div className="flex flex-wrap gap-2 pt-4 border-t">
                <span className="text-sm font-medium text-slate-700">Active filters:</span>
                {search && (
                  <Badge variant="secondary" className="cursor-pointer" onClick={() => setSearch("")}>
                    Search: "{search}" ×
                  </Badge>
                )}
                {category && (
                  <Badge variant="secondary" className="cursor-pointer" onClick={() => setCategory("")}>
                    Category: {category} ×
                  </Badge>
                )}
                {followerRange && (
                  <Badge variant="secondary" className="cursor-pointer" onClick={() => setFollowerRange("")}>
                    Followers: {followerRange} ×
                  </Badge>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-900">
            {influencersLoading ? "Loading..." : `${influencers?.length || 0} Influencers Found`}
          </h3>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Sort by Engagement
            </Button>
          </div>
        </div>
      </div>

      {/* Influencers Grid */}
      {influencersLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-slate-200 rounded-lg h-64"></div>
            </div>
          ))}
        </div>
      ) : influencers && influencers.length > 0 ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {influencers.map((influencer: any) => (
              <InfluencerCard key={influencer.id} influencer={influencer} />
            ))}
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-center space-x-4 mt-8">
            <Button
              variant="outline"
              disabled={page === 0}
              onClick={() => setPage(page - 1)}
            >
              Previous
            </Button>
            <span className="text-sm text-slate-600">
              Page {page + 1}
            </span>
            <Button
              variant="outline"
              disabled={!influencers || influencers.length < 20}
              onClick={() => setPage(page + 1)}
            >
              Next
            </Button>
          </div>
        </>
      ) : (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <Search className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No influencers found</h3>
              <p className="text-slate-500 mb-4">
                Try adjusting your search criteria or filters to find more results.
              </p>
              <Button variant="outline" onClick={handleResetFilters}>
                Reset All Filters
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
