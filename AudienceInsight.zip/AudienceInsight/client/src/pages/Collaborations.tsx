import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, MessageCircle, CheckCircle, Clock, X, Plus, Filter } from "lucide-react";

export default function Collaborations() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [statusFilter, setStatusFilter] = useState("");

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: collaborations, isLoading: collaborationsLoading, error } = useQuery({
    queryKey: ["/api/collaborations", statusFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (statusFilter) params.append("status", statusFilter);
      const response = await fetch(`/api/collaborations?${params}`, {
        credentials: "include",
      });
      if (!response.ok) {
        const text = await response.text();
        throw new Error(`${response.status}: ${text}`);
      }
      return response.json();
    },
    retry: false,
  });

  const updateCollaborationMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      await apiRequest("PUT", `/api/collaborations/${id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/collaborations"] });
      toast({
        title: "Success",
        description: "Collaboration updated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update collaboration. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [error, toast]);

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'accepted':
        return 'default';
      case 'completed':
        return 'secondary';
      case 'declined':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted':
        return 'bg-emerald-100 text-emerald-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'declined':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'accepted':
        return <CheckCircle className="h-4 w-4" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4" />;
      case 'declined':
        return <X className="h-4 w-4" />;
      case 'pending':
        return <Clock className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-200 rounded w-1/3"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-32 bg-slate-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold leading-7 text-slate-900 sm:text-3xl">
            Collaborations
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Manage your influencer partnerships and track collaboration progress
          </p>
        </div>
        <div className="mt-4 flex md:mt-0 md:ml-4 space-x-3">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button className="bg-primary-600 hover:bg-primary-700">
            <Plus className="h-4 w-4 mr-2" />
            New Collaboration
          </Button>
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="mb-6">
        <div className="border-b border-slate-200">
          <nav className="-mb-px flex space-x-8">
            {['', 'pending', 'accepted', 'completed', 'declined'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`${
                  statusFilter === status
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                } whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm`}
              >
                {status === '' ? 'All Collaborations' : status.charAt(0).toUpperCase() + status.slice(1)}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Collaborations List */}
      {collaborationsLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="animate-pulse h-32 bg-slate-200 rounded-lg"></div>
          ))}
        </div>
      ) : collaborations && collaborations.length > 0 ? (
        <div className="space-y-6">
          {collaborations.map((collaboration: any) => (
            <Card key={collaboration.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start space-x-4 flex-1">
                    <Avatar className="h-12 w-12">
                      <AvatarImage 
                        src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=48&h=48"
                        alt="Influencer"
                      />
                      <AvatarFallback>IN</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-slate-900">
                          Emma Rodriguez
                        </h3>
                        <Badge className={getStatusColor(collaboration.status)}>
                          <span className="flex items-center space-x-1">
                            {getStatusIcon(collaboration.status)}
                            <span>{collaboration.status}</span>
                          </span>
                        </Badge>
                      </div>
                      <p className="text-slate-600 mb-2">Fashion & Lifestyle • 245K followers</p>
                      <div className="flex items-center space-x-6 text-sm text-slate-500">
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-1" />
                          Campaign: Summer Fashion Collection
                        </div>
                        {collaboration.agreedRate && (
                          <div>
                            Rate: ${collaboration.agreedRate}/post
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Message
                    </Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>Collaboration Details</DialogTitle>
                          <DialogDescription>
                            Manage this collaboration and track deliverables
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-6">
                          <div>
                            <h4 className="font-medium text-slate-900 mb-2">Deliverables</h4>
                            <div className="bg-slate-50 rounded-lg p-4">
                              <div className="grid grid-cols-3 gap-4 text-sm">
                                <div className="text-center">
                                  <div className="text-lg font-semibold text-slate-900">3</div>
                                  <div className="text-slate-500">Instagram Posts</div>
                                </div>
                                <div className="text-center">
                                  <div className="text-lg font-semibold text-slate-900">5</div>
                                  <div className="text-slate-500">Stories</div>
                                </div>
                                <div className="text-center">
                                  <div className="text-lg font-semibold text-slate-900">1</div>
                                  <div className="text-slate-500">Reel</div>
                                </div>
                              </div>
                            </div>
                          </div>

                          {collaboration.status === 'completed' && (
                            <div>
                              <h4 className="font-medium text-slate-900 mb-2">Performance Metrics</h4>
                              <div className="bg-slate-50 rounded-lg p-4">
                                <div className="grid grid-cols-3 gap-4 text-sm">
                                  <div className="text-center">
                                    <div className="text-lg font-semibold text-emerald-600">150K</div>
                                    <div className="text-slate-500">Total Reach</div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-lg font-semibold text-emerald-600">7.2%</div>
                                    <div className="text-slate-500">Engagement Rate</div>
                                  </div>
                                  <div className="text-center">
                                    <div className="text-lg font-semibold text-emerald-600">450</div>
                                    <div className="text-slate-500">Clicks</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}

                          {collaboration.status === 'pending' && (
                            <div className="flex justify-end space-x-3">
                              <Button 
                                variant="outline"
                                onClick={() => updateCollaborationMutation.mutate({ id: collaboration.id, status: 'declined' })}
                                disabled={updateCollaborationMutation.isPending}
                              >
                                Decline
                              </Button>
                              <Button 
                                onClick={() => updateCollaborationMutation.mutate({ id: collaboration.id, status: 'accepted' })}
                                disabled={updateCollaborationMutation.isPending}
                                className="bg-primary-600 hover:bg-primary-700"
                              >
                                Accept
                              </Button>
                            </div>
                          )}

                          {collaboration.status === 'accepted' && (
                            <div className="flex justify-end">
                              <Button 
                                onClick={() => updateCollaborationMutation.mutate({ id: collaboration.id, status: 'completed' })}
                                disabled={updateCollaborationMutation.isPending}
                                className="bg-emerald-600 hover:bg-emerald-700"
                              >
                                Mark as Completed
                              </Button>
                            </div>
                          )}
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>

                {collaboration.status === 'accepted' && (
                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-slate-700">Progress</span>
                      <span className="text-sm text-slate-500">3 of 9 deliverables completed</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-primary-600 h-2 rounded-full" style={{ width: '33%' }}></div>
                    </div>
                  </div>
                )}

                {collaboration.status === 'completed' && (
                  <div className="border-t pt-4">
                    <div className="grid grid-cols-4 gap-4 text-center">
                      <div>
                        <div className="text-lg font-semibold text-emerald-600">150K</div>
                        <div className="text-xs text-slate-500">Total Reach</div>
                      </div>
                      <div>
                        <div className="text-lg font-semibold text-emerald-600">7.2%</div>
                        <div className="text-xs text-slate-500">Engagement</div>
                      </div>
                      <div>
                        <div className="text-lg font-semibold text-emerald-600">450</div>
                        <div className="text-xs text-slate-500">Clicks</div>
                      </div>
                      <div>
                        <div className="text-lg font-semibold text-emerald-600">380% ROI</div>
                        <div className="text-xs text-slate-500">Performance</div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12">
            <div className="text-center">
              <Users className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No collaborations found</h3>
              <p className="text-slate-500 mb-6">
                {statusFilter 
                  ? `No collaborations with status "${statusFilter}" found.`
                  : "Start building relationships with influencers by creating collaborations."
                }
              </p>
              <Button className="bg-primary-600 hover:bg-primary-700">
                <Plus className="h-4 w-4 mr-2" />
                Create New Collaboration
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
