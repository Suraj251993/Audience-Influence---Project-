import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, Users, Target, TrendingUp, Star, CheckCircle } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-slate-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">AI</span>
              </div>
              <h1 className="text-xl font-bold text-slate-900">Audience Influence</h1>
            </div>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-primary-600 hover:bg-primary-700"
            >
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4">
            Influencer Marketing Platform
          </Badge>
          <h1 className="text-4xl sm:text-6xl font-bold text-slate-900 mb-6">
            Connect Brands with
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-600 to-secondary-600">
              {" "}Top Influencers
            </span>
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
            Streamline your influencer marketing campaigns, discover authentic creators, 
            and track performance with our comprehensive platform designed for modern brands.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => window.location.href = '/api/login'}
              className="bg-primary-600 hover:bg-primary-700 px-8"
            >
              Get Started
            </Button>
            <Button size="lg" variant="outline" className="px-8">
              Learn More
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="border-slate-200 hover:shadow-lg transition-shadow">
            <CardHeader className="pb-4">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-primary-600" />
              </div>
              <CardTitle className="text-lg">Discover Influencers</CardTitle>
              <CardDescription>
                Find the perfect creators for your brand with advanced filtering and search.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-slate-200 hover:shadow-lg transition-shadow">
            <CardHeader className="pb-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <Target className="h-6 w-6 text-emerald-600" />
              </div>
              <CardTitle className="text-lg">Campaign Management</CardTitle>
              <CardDescription>
                Create, track, and optimize your influencer marketing campaigns in one place.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-slate-200 hover:shadow-lg transition-shadow">
            <CardHeader className="pb-4">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="h-6 w-6 text-amber-600" />
              </div>
              <CardTitle className="text-lg">Real-time Analytics</CardTitle>
              <CardDescription>
                Monitor performance metrics, ROI, and engagement rates with detailed reports.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-slate-200 hover:shadow-lg transition-shadow">
            <CardHeader className="pb-4">
              <div className="w-12 h-12 bg-secondary-100 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="h-6 w-6 text-secondary-600" />
              </div>
              <CardTitle className="text-lg">Performance Optimization</CardTitle>
              <CardDescription>
                Leverage AI-driven insights to maximize your campaign effectiveness.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Benefits Section */}
        <div className="bg-white rounded-2xl border border-slate-200 p-8 lg:p-12 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-6">
                Why Choose Audience Influence?
              </h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-emerald-500 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-slate-900">Verified Influencers</h3>
                    <p className="text-slate-600">Access to authentic, vetted creators across all major platforms.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-emerald-500 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-slate-900">Advanced Analytics</h3>
                    <p className="text-slate-600">Comprehensive performance tracking and ROI measurement tools.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-emerald-500 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-slate-900">Seamless Collaboration</h3>
                    <p className="text-slate-600">Streamlined communication and project management features.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-emerald-500 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-slate-900">Expert Support</h3>
                    <p className="text-slate-600">Dedicated account management and campaign optimization support.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-xl p-8 border-2 border-dashed border-primary-200">
              <div className="text-center">
                <Star className="h-16 w-16 text-primary-500 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Ready to Start?</h3>
                <p className="text-slate-600 mb-6">
                  Join thousands of brands already using our platform to amplify their reach.
                </p>
                <Button 
                  size="lg" 
                  onClick={() => window.location.href = '/api/login'}
                  className="bg-primary-600 hover:bg-primary-700"
                >
                  Start Your Campaign
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gradient-to-r from-primary-600 to-secondary-600 rounded-2xl p-12 text-white">
          <h2 className="text-3xl font-bold mb-4">
            Transform Your Influencer Marketing Today
          </h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Connect with authentic creators, launch impactful campaigns, and measure real results 
            with our comprehensive influencer marketing platform.
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            onClick={() => window.location.href = '/api/login'}
            className="bg-white text-primary-600 hover:bg-slate-50 px-8"
          >
            Get Started Free
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12 mt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">AI</span>
              </div>
              <span className="text-xl font-bold">Audience Influence</span>
            </div>
            <div className="text-slate-400">
              © 2024 Audience Influence. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
