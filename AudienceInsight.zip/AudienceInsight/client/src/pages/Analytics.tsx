import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PerformanceChart from "@/components/PerformanceChart";
import { TrendingUp, Users, Target, DollarSign, Download, Calendar } from "lucide-react";

export default function Analytics() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-slate-200 rounded-lg"></div>
            ))}
          </div>
          <div className="h-64 bg-slate-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold leading-7 text-slate-900 sm:text-3xl">
            Analytics Dashboard
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Comprehensive insights into your influencer marketing performance
          </p>
        </div>
        <div className="mt-4 flex md:mt-0 md:ml-4 space-x-3">
          <Select defaultValue="30">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Performance Metrics */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-primary-600" />
                </div>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Total Reach</dt>
                  <dd className="text-lg font-semibold text-slate-900">8.4M</dd>
                </dl>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center text-sm">
                <span className="text-emerald-600 font-medium">+24.5%</span>
                <span className="text-slate-500 ml-1">vs last period</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
                  <Target className="h-5 w-5 text-emerald-600" />
                </div>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Avg Engagement Rate</dt>
                  <dd className="text-lg font-semibold text-slate-900">5.7%</dd>
                </dl>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center text-sm">
                <span className="text-emerald-600 font-medium">+1.2%</span>
                <span className="text-slate-500 ml-1">vs last period</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-5 w-5 text-amber-600" />
                </div>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Cost Per Engagement</dt>
                  <dd className="text-lg font-semibold text-slate-900">$0.12</dd>
                </dl>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center text-sm">
                <span className="text-emerald-600 font-medium">-8.3%</span>
                <span className="text-slate-500 ml-1">vs last period</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-secondary-100 rounded-lg flex items-center justify-center">
                  <Users className="h-5 w-5 text-secondary-600" />
                </div>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-slate-500 truncate">Active Collaborations</dt>
                  <dd className="text-lg font-semibold text-slate-900">47</dd>
                </dl>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center text-sm">
                <span className="text-emerald-600 font-medium">+12</span>
                <span className="text-slate-500 ml-1">new this month</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Over Time */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <PerformanceChart />
        </div>

        {/* Campaign Performance Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Campaign Performance</CardTitle>
            <CardDescription>ROI breakdown by campaign type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-900">Fashion & Lifestyle</div>
                  <div className="text-sm text-slate-500">8 campaigns</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-emerald-600">462% ROI</div>
                  <div className="text-sm text-slate-500">$2.1M reach</div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-900">Technology</div>
                  <div className="text-sm text-slate-500">5 campaigns</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-emerald-600">398% ROI</div>
                  <div className="text-sm text-slate-500">$1.8M reach</div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-900">Health & Fitness</div>
                  <div className="text-sm text-slate-500">6 campaigns</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-emerald-600">334% ROI</div>
                  <div className="text-sm text-slate-500">$1.5M reach</div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-900">Food & Cooking</div>
                  <div className="text-sm text-slate-500">4 campaigns</div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-emerald-600">287% ROI</div>
                  <div className="text-sm text-slate-500">$1.2M reach</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Performing Content */}
        <Card>
          <CardHeader>
            <CardTitle>Top Performing Content</CardTitle>
            <CardDescription>Highest engagement posts this month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <img
                  className="h-12 w-12 rounded-lg object-cover"
                  src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=48&h=48"
                  alt="Content thumbnail"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900">Summer Fashion Lookbook</p>
                  <p className="text-sm text-slate-500">@emmarodriguez • Fashion</p>
                  <div className="mt-1 flex items-center space-x-4 text-xs text-slate-500">
                    <span>124K likes</span>
                    <span>8.7% engagement</span>
                    <span>2.1K comments</span>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <img
                  className="h-12 w-12 rounded-lg object-cover"
                  src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=48&h=48"
                  alt="Content thumbnail"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900">Tech Review: Latest Smartphone</p>
                  <p className="text-sm text-slate-500">@alexchen • Technology</p>
                  <div className="mt-1 flex items-center space-x-4 text-xs text-slate-500">
                    <span>89K likes</span>
                    <span>7.2% engagement</span>
                    <span>1.8K comments</span>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <img
                  className="h-12 w-12 rounded-lg object-cover"
                  src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=48&h=48"
                  alt="Content thumbnail"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900">Morning Workout Routine</p>
                  <p className="text-sm text-slate-500">@mayapatel • Fitness</p>
                  <div className="mt-1 flex items-center space-x-4 text-xs text-slate-500">
                    <span>67K likes</span>
                    <span>6.8% engagement</span>
                    <span>1.2K comments</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Audience Demographics */}
        <Card>
          <CardHeader>
            <CardTitle>Audience Demographics</CardTitle>
            <CardDescription>Understanding your campaign reach</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-medium text-slate-900 mb-3">Age Groups</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">18-24</span>
                    <span className="text-sm font-medium">32%</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div className="bg-primary-600 h-2 rounded-full" style={{ width: '32%' }}></div>
                  </div>
                </div>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">25-34</span>
                    <span className="text-sm font-medium">28%</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div className="bg-primary-600 h-2 rounded-full" style={{ width: '28%' }}></div>
                  </div>
                </div>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">35-44</span>
                    <span className="text-sm font-medium">24%</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div className="bg-primary-600 h-2 rounded-full" style={{ width: '24%' }}></div>
                  </div>
                </div>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600">45+</span>
                    <span className="text-sm font-medium">16%</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div className="bg-primary-600 h-2 rounded-full" style={{ width: '16%' }}></div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-slate-900 mb-3">Gender Distribution</h4>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-primary-600 rounded-full mr-2"></div>
                    <span className="text-sm text-slate-600">Female 58%</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-secondary-600 rounded-full mr-2"></div>
                    <span className="text-sm text-slate-600">Male 42%</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
