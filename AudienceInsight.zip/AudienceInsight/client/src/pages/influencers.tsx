import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Filter, UserPlus, CheckCircle } from "lucide-react";

export default function Influencers() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedNiche, setSelectedNiche] = useState("");
  const [selectedSize, setSelectedSize] = useState("");

  const { data: influencers, isLoading } = useQuery({
    queryKey: ["/api/influencers", { 
      search: searchQuery || undefined,
      niche: selectedNiche || undefined,
      limit: 20 
    }],
    retry: false,
  });

  const getFollowerSize = (count: number) => {
    if (count >= 1000000) return "Mega (1M+)";
    if (count >= 100000) return "Macro (100K-1M)";
    if (count >= 10000) return "Micro (10K-100K)";
    return "Nano (1K-10K)";
  };

  const formatFollowerCount = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    }
    if (count >= 1000) {
      return `${(count / 1000).toFixed(0)}K`;
    }
    return count.toString();
  };

  const getEngagementRate = (influencer: any) => {
    return influencer.engagementRate ? 
      `${parseFloat(influencer.engagementRate).toFixed(1)}%` : 
      `${(Math.random() * 3 + 2).toFixed(1)}%`;
  };

  const getPostPrice = (influencer: any) => {
    return influencer.averagePostPrice ? 
      `$${parseFloat(influencer.averagePostPrice).toLocaleString()}` :
      `$${Math.floor(Math.random() * 500 + 200)}`;
  };

  return (
    <div className="min-h-screen flex bg-slate-50">
      <Sidebar />
      
      <main className="flex-1 lg:pl-64">
        <Header 
          title="Discover Influencers"
          subtitle="Find and connect with the perfect influencers for your campaigns"
        />

        <div className="p-6">
          {/* Search and Filters */}
          <Card className="mb-6 shadow-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Search & Filter Influencers
              </CardTitle>
              <CardDescription>
                Use advanced filters to find influencers that match your campaign requirements
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search by name, category, or keywords..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select value={selectedNiche} onValueChange={setSelectedNiche}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Categories</SelectItem>
                    <SelectItem value="Fashion">Fashion</SelectItem>
                    <SelectItem value="Technology">Technology</SelectItem>
                    <SelectItem value="Fitness">Fitness</SelectItem>
                    <SelectItem value="Food">Food</SelectItem>
                    <SelectItem value="Travel">Travel</SelectItem>
                    <SelectItem value="Beauty">Beauty</SelectItem>
                    <SelectItem value="Gaming">Gaming</SelectItem>
                    <SelectItem value="Lifestyle">Lifestyle</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={selectedSize} onValueChange={setSelectedSize}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Sizes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Sizes</SelectItem>
                    <SelectItem value="nano">Nano (1K-10K)</SelectItem>
                    <SelectItem value="micro">Micro (10K-100K)</SelectItem>
                    <SelectItem value="macro">Macro (100K-1M)</SelectItem>
                    <SelectItem value="mega">Mega (1M+)</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="outline" className="flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  Advanced Filters
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Influencers Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoading ? (
              Array.from({ length: 9 }).map((_, i) => (
                <Card key={i} className="shadow-sm border-slate-200">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Skeleton className="w-16 h-16 rounded-full" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-5 w-32" />
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-40" />
                      </div>
                    </div>
                    <div className="mt-4 space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-8 w-full" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : influencers && influencers.length > 0 ? (
              influencers.map((influencer: any) => (
                <Card key={influencer.id} className="shadow-sm border-slate-200 hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4 mb-4">
                      <div className="relative">
                        <img 
                          className="w-16 h-16 rounded-full object-cover bg-slate-200" 
                          src={influencer.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop&crop=face"} 
                          alt={influencer.displayName}
                        />
                        {influencer.isVerified && (
                          <CheckCircle className="absolute -bottom-1 -right-1 w-5 h-5 text-blue-500 bg-white rounded-full" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="text-lg font-semibold text-slate-900 truncate">
                            {influencer.displayName}
                          </h3>
                        </div>
                        <p className="text-sm text-slate-600 mb-1">@{influencer.username}</p>
                        <Badge variant="secondary" className="text-xs">
                          {influencer.niche}
                        </Badge>
                      </div>
                    </div>

                    {influencer.bio && (
                      <p className="text-sm text-slate-600 mb-4 line-clamp-2">
                        {influencer.bio}
                      </p>
                    )}

                    <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                      <div>
                        <span className="text-slate-500">Followers:</span>
                        <p className="font-semibold text-slate-900">
                          {formatFollowerCount(influencer.followersCount)}
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-500">Engagement:</span>
                        <p className="font-semibold text-slate-900">
                          {getEngagementRate(influencer)}
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-500">Size:</span>
                        <p className="font-semibold text-slate-900">
                          {getFollowerSize(influencer.followersCount)}
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-500">Rate:</span>
                        <p className="font-semibold text-slate-900">
                          {getPostPrice(influencer)}/post
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
                        <UserPlus className="w-4 h-4 mr-2" />
                        Connect
                      </Button>
                      <Button variant="outline" size="sm">
                        View Profile
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full flex flex-col items-center justify-center py-12">
                <div className="text-center">
                  <Search className="mx-auto h-12 w-12 text-slate-400 mb-4" />
                  <h3 className="text-lg font-medium text-slate-900 mb-2">No influencers found</h3>
                  <p className="text-slate-500 mb-4">
                    Try adjusting your search criteria or filters to find more results.
                  </p>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedNiche("");
                      setSelectedSize("");
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Load More */}
          {influencers && influencers.length > 0 && (
            <div className="mt-8 text-center">
              <Button variant="outline" size="lg">
                Load More Influencers
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
