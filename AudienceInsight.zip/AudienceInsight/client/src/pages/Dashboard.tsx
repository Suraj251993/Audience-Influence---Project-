import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import { isUnauthorizedError } from "@/lib/authUtils";
import MetricsCard from "@/components/MetricsCard";
import PerformanceChart from "@/components/PerformanceChart";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, TrendingUp, Target, DollarSign, Plus, Filter } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
    retry: false,
  });

  const { data: campaigns, isLoading: campaignsLoading } = useQuery({
    queryKey: ["/api/campaigns"],
    retry: false,
  });

  if (isLoading || metricsLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-slate-200 rounded-lg"></div>
            ))}
          </div>
          <div className="h-64 bg-slate-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold leading-7 text-slate-900 sm:text-3xl sm:truncate">
            Dashboard Overview
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Track your influencer marketing performance and campaign metrics
          </p>
        </div>
        <div className="mt-4 flex md:mt-0 md:ml-4 space-x-3">
          <Button variant="outline" className="inline-flex items-center">
            <Filter className="h-4 w-4 mr-2" />
            Export Report
          </Button>
          <Link href="/campaigns">
            <Button className="inline-flex items-center bg-primary-600 hover:bg-primary-700">
              <Plus className="h-4 w-4 mr-2" />
              New Campaign
            </Button>
          </Link>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <MetricsCard
          title="Total Reach"
          value={metrics?.totalReach?.toLocaleString() || "0"}
          change="+12.5%"
          changeType="positive"
          icon={<TrendingUp className="h-5 w-5" />}
          iconColor="bg-primary-100 text-primary-600"
        />
        <MetricsCard
          title="Campaign ROI"
          value={`${metrics?.campaignROI || 0}%`}
          change="+8.2%"
          changeType="positive"
          icon={<DollarSign className="h-5 w-5" />}
          iconColor="bg-emerald-100 text-emerald-600"
        />
        <MetricsCard
          title="Active Influencers"
          value={metrics?.activeInfluencers?.toString() || "0"}
          change="+23"
          changeType="positive"
          icon={<Users className="h-5 w-5" />}
          iconColor="bg-secondary-100 text-secondary-600"
        />
        <MetricsCard
          title="Active Campaigns"
          value={metrics?.activeCampaigns?.toString() || "0"}
          change="+3"
          changeType="positive"
          icon={<Target className="h-5 w-5" />}
          iconColor="bg-amber-100 text-amber-600"
        />
      </div>

      {/* Charts and Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Performance Chart */}
        <div className="lg:col-span-2">
          <PerformanceChart />
        </div>

        {/* Top Performers */}
        <Card>
          <CardHeader>
            <CardTitle>Top Performers</CardTitle>
            <CardDescription>Highest ROI influencers this month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Sample data - in real app this would come from API */}
              <div className="flex items-center space-x-4">
                <img
                  className="h-10 w-10 rounded-full object-cover"
                  src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"
                  alt="Influencer"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900">Emma Rodriguez</p>
                  <p className="text-sm text-slate-500">Fashion & Lifestyle</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">450% ROI</p>
                  <p className="text-sm text-slate-500">125K reach</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <img
                  className="h-10 w-10 rounded-full object-cover"
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"
                  alt="Influencer"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900">Alex Chen</p>
                  <p className="text-sm text-slate-500">Technology</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">380% ROI</p>
                  <p className="text-sm text-slate-500">89K reach</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <img
                  className="h-10 w-10 rounded-full object-cover"
                  src="https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"
                  alt="Influencer"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900">Maya Patel</p>
                  <p className="text-sm text-slate-500">Health & Fitness</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">340% ROI</p>
                  <p className="text-sm text-slate-500">67K reach</p>
                </div>
              </div>
            </div>
            <div className="mt-6">
              <Link href="/discover">
                <Button variant="outline" className="w-full">
                  View All Influencers
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Campaigns */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Recent Campaigns</CardTitle>
              <CardDescription>Track and manage your active marketing campaigns</CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {campaignsLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse h-16 bg-slate-200 rounded"></div>
              ))}
            </div>
          ) : campaigns && campaigns.length > 0 ? (
            <div className="space-y-4">
              {campaigns.slice(0, 5).map((campaign: any) => (
                <div key={campaign.id} className="border border-slate-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-medium text-slate-900">{campaign.name}</h4>
                      <p className="text-sm text-slate-600">{campaign.category}</p>
                    </div>
                    <Badge 
                      variant={campaign.status === 'active' ? 'default' : 
                               campaign.status === 'completed' ? 'secondary' : 'outline'}
                      className={campaign.status === 'active' ? 'bg-emerald-100 text-emerald-800' :
                                campaign.status === 'completed' ? 'bg-slate-100 text-slate-800' :
                                'bg-yellow-100 text-yellow-800'}
                    >
                      {campaign.status}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-slate-600 mb-3">
                    <span>Budget: ${campaign.budget?.toLocaleString()}</span>
                    <span>
                      {campaign.startDate && campaign.endDate 
                        ? `${new Date(campaign.startDate).toLocaleDateString()} - ${new Date(campaign.endDate).toLocaleDateString()}`
                        : 'Dates TBD'
                      }
                    </span>
                  </div>
                  
                  {campaign.status === 'active' && (
                    <>
                      <div className="bg-slate-100 rounded-full h-2 mb-1">
                        <div 
                          className="bg-primary-600 rounded-full h-2" 
                          style={{ width: '68%' }}
                        ></div>
                      </div>
                      <p className="text-xs text-slate-600">68% complete</p>
                    </>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Target className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <p className="text-slate-500 mb-4">No campaigns yet</p>
              <Link href="/campaigns">
                <Button>Create Your First Campaign</Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
