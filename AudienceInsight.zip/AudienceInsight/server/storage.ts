import {
  users,
  influencers,
  campaigns,
  collaborations,
  campaignAnalytics,
  type User,
  type UpsertUser,
  type Influencer,
  type InsertInfluencer,
  type Campaign,
  type InsertCampaign,
  type Collaboration,
  type InsertCollaboration,
  type CampaignAnalytics,
  type InsertCampaignAnalytics,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, ilike, and, sql, count, sum } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Influencer operations
  getInfluencers(params?: {
    search?: string;
    niche?: string;
    minFollowers?: number;
    maxFollowers?: number;
    limit?: number;
    offset?: number;
  }): Promise<Influencer[]>;
  getInfluencer(id: number): Promise<Influencer | undefined>;
  createInfluencer(influencer: InsertInfluencer): Promise<Influencer>;
  updateInfluencer(id: number, influencer: Partial<InsertInfluencer>): Promise<Influencer>;
  deleteInfluencer(id: number): Promise<void>;
  getTopPerformingInfluencers(limit?: number): Promise<Array<Influencer & { roi: string; reach: number }>>;

  // Campaign operations
  getCampaigns(userId?: string, params?: {
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<Array<Campaign & { influencerCount: number }>>;
  getCampaign(id: number): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: number, campaign: Partial<InsertCampaign>): Promise<Campaign>;
  deleteCampaign(id: number): Promise<void>;

  // Collaboration operations
  getCollaborations(campaignId?: number, influencerId?: number): Promise<Array<Collaboration & { campaign?: Campaign; influencer?: Influencer }>>;
  createCollaboration(collaboration: InsertCollaboration): Promise<Collaboration>;
  updateCollaboration(id: number, collaboration: Partial<InsertCollaboration>): Promise<Collaboration>;
  deleteCollaboration(id: number): Promise<void>;

  // Analytics operations
  getCampaignAnalytics(campaignId: number): Promise<CampaignAnalytics[]>;
  createCampaignAnalytics(analytics: InsertCampaignAnalytics): Promise<CampaignAnalytics>;
  getDashboardMetrics(userId?: string): Promise<{
    totalReach: number;
    roi: string;
    activeInfluencers: number;
    activeCampaigns: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Influencer operations
  async getInfluencers(params: {
    search?: string;
    niche?: string;
    minFollowers?: number;
    maxFollowers?: number;
    limit?: number;
    offset?: number;
  } = {}): Promise<Influencer[]> {
    const {
      search,
      niche,
      minFollowers,
      maxFollowers,
      limit = 20,
      offset = 0,
    } = params;

    let query = db.select().from(influencers);

    const conditions = [];
    if (search) {
      conditions.push(ilike(influencers.name, `%${search}%`));
    }
    if (niche) {
      conditions.push(eq(influencers.niche, niche));
    }
    if (minFollowers) {
      conditions.push(sql`${influencers.followers} >= ${minFollowers}`);
    }
    if (maxFollowers) {
      conditions.push(sql`${influencers.followers} <= ${maxFollowers}`);
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const result = await query
      .orderBy(desc(influencers.followers))
      .limit(limit)
      .offset(offset);

    return result;
  }

  async getInfluencer(id: number): Promise<Influencer | undefined> {
    const [influencer] = await db
      .select()
      .from(influencers)
      .where(eq(influencers.id, id));
    return influencer;
  }

  async createInfluencer(influencerData: InsertInfluencer): Promise<Influencer> {
    const [influencer] = await db
      .insert(influencers)
      .values(influencerData)
      .returning();
    return influencer;
  }

  async updateInfluencer(id: number, influencerData: Partial<InsertInfluencer>): Promise<Influencer> {
    const [influencer] = await db
      .update(influencers)
      .set({ ...influencerData, updatedAt: new Date() })
      .where(eq(influencers.id, id))
      .returning();
    return influencer;
  }

  async deleteInfluencer(id: number): Promise<void> {
    await db.delete(influencers).where(eq(influencers.id, id));
  }

  async getTopPerformingInfluencers(limit = 10): Promise<Array<Influencer & { roi: string; reach: number }>> {
    const result = await db
      .select({
        id: influencers.id,
        name: influencers.name,
        email: influencers.email,
        profileImageUrl: influencers.profileImageUrl,
        bio: influencers.bio,
        niche: influencers.niche,
        followers: influencers.followers,
        engagementRate: influencers.engagementRate,
        averagePostCost: influencers.averagePostCost,
        isVerified: influencers.isVerified,
        socialPlatforms: influencers.socialPlatforms,
        createdAt: influencers.createdAt,
        updatedAt: influencers.updatedAt,
        roi: sql<string>`COALESCE(AVG(${campaignAnalytics.roi}), 0)::text`,
        reach: sql<number>`COALESCE(SUM(${campaignAnalytics.totalReach}), 0)::int`,
      })
      .from(influencers)
      .leftJoin(collaborations, eq(influencers.id, collaborations.influencerId))
      .leftJoin(campaignAnalytics, eq(collaborations.campaignId, campaignAnalytics.campaignId))
      .groupBy(influencers.id)
      .orderBy(desc(sql`COALESCE(AVG(${campaignAnalytics.roi}), 0)`))
      .limit(limit);

    return result;
  }

  // Campaign operations
  async getCampaigns(userId?: string, params: {
    status?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<Array<Campaign & { influencerCount: number }>> {
    const { status, limit = 20, offset = 0 } = params;

    let query = db
      .select({
        id: campaigns.id,
        name: campaigns.name,
        description: campaigns.description,
        budget: campaigns.budget,
        status: campaigns.status,
        category: campaigns.category,
        startDate: campaigns.startDate,
        endDate: campaigns.endDate,
        createdBy: campaigns.createdBy,
        targetAudience: campaigns.targetAudience,
        goals: campaigns.goals,
        createdAt: campaigns.createdAt,
        updatedAt: campaigns.updatedAt,
        influencerCount: sql<number>`COALESCE(COUNT(${collaborations.influencerId}), 0)::int`,
      })
      .from(campaigns)
      .leftJoin(collaborations, eq(campaigns.id, collaborations.campaignId));

    const conditions = [];
    if (userId) {
      conditions.push(eq(campaigns.createdBy, userId));
    }
    if (status) {
      conditions.push(eq(campaigns.status, status));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const result = await query
      .groupBy(campaigns.id)
      .orderBy(desc(campaigns.createdAt))
      .limit(limit)
      .offset(offset);

    return result;
  }

  async getCampaign(id: number): Promise<Campaign | undefined> {
    const [campaign] = await db
      .select()
      .from(campaigns)
      .where(eq(campaigns.id, id));
    return campaign;
  }

  async createCampaign(campaignData: InsertCampaign): Promise<Campaign> {
    const [campaign] = await db
      .insert(campaigns)
      .values(campaignData)
      .returning();
    return campaign;
  }

  async updateCampaign(id: number, campaignData: Partial<InsertCampaign>): Promise<Campaign> {
    const [campaign] = await db
      .update(campaigns)
      .set({ ...campaignData, updatedAt: new Date() })
      .where(eq(campaigns.id, id))
      .returning();
    return campaign;
  }

  async deleteCampaign(id: number): Promise<void> {
    await db.delete(campaigns).where(eq(campaigns.id, id));
  }

  // Collaboration operations
  async getCollaborations(campaignId?: number, influencerId?: number): Promise<Array<Collaboration & { campaign?: Campaign; influencer?: Influencer }>> {
    let query = db
      .select({
        id: collaborations.id,
        campaignId: collaborations.campaignId,
        influencerId: collaborations.influencerId,
        status: collaborations.status,
        agreedRate: collaborations.agreedRate,
        deliverables: collaborations.deliverables,
        notes: collaborations.notes,
        createdAt: collaborations.createdAt,
        updatedAt: collaborations.updatedAt,
        campaign: campaigns,
        influencer: influencers,
      })
      .from(collaborations)
      .leftJoin(campaigns, eq(collaborations.campaignId, campaigns.id))
      .leftJoin(influencers, eq(collaborations.influencerId, influencers.id));

    const conditions = [];
    if (campaignId) {
      conditions.push(eq(collaborations.campaignId, campaignId));
    }
    if (influencerId) {
      conditions.push(eq(collaborations.influencerId, influencerId));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query.orderBy(desc(collaborations.createdAt));
  }

  async createCollaboration(collaborationData: InsertCollaboration): Promise<Collaboration> {
    const [collaboration] = await db
      .insert(collaborations)
      .values(collaborationData)
      .returning();
    return collaboration;
  }

  async updateCollaboration(id: number, collaborationData: Partial<InsertCollaboration>): Promise<Collaboration> {
    const [collaboration] = await db
      .update(collaborations)
      .set({ ...collaborationData, updatedAt: new Date() })
      .where(eq(collaborations.id, id))
      .returning();
    return collaboration;
  }

  async deleteCollaboration(id: number): Promise<void> {
    await db.delete(collaborations).where(eq(collaborations.id, id));
  }

  // Analytics operations
  async getCampaignAnalytics(campaignId: number): Promise<CampaignAnalytics[]> {
    return await db
      .select()
      .from(campaignAnalytics)
      .where(eq(campaignAnalytics.campaignId, campaignId))
      .orderBy(desc(campaignAnalytics.recordedAt));
  }

  async createCampaignAnalytics(analyticsData: InsertCampaignAnalytics): Promise<CampaignAnalytics> {
    const [analytics] = await db
      .insert(campaignAnalytics)
      .values(analyticsData)
      .returning();
    return analytics;
  }

  async getDashboardMetrics(userId?: string): Promise<{
    totalReach: number;
    roi: string;
    activeInfluencers: number;
    activeCampaigns: number;
  }> {
    // Get campaigns for the user
    const userCampaignsQuery = userId 
      ? db.select({ id: campaigns.id }).from(campaigns).where(eq(campaigns.createdBy, userId))
      : db.select({ id: campaigns.id }).from(campaigns);

    const userCampaigns = await userCampaignsQuery;
    const campaignIds = userCampaigns.map(c => c.id);

    if (campaignIds.length === 0) {
      return {
        totalReach: 0,
        roi: "0.00",
        activeInfluencers: 0,
        activeCampaigns: 0,
      };
    }

    // Get analytics for user's campaigns
    const [analyticsResult] = await db
      .select({
        totalReach: sql<number>`COALESCE(SUM(${campaignAnalytics.totalReach}), 0)::int`,
        avgRoi: sql<string>`COALESCE(AVG(${campaignAnalytics.roi}), 0)::text`,
      })
      .from(campaignAnalytics)
      .where(sql`${campaignAnalytics.campaignId} = ANY(${campaignIds})`);

    // Get active campaigns count
    const [activeCampaignsResult] = await db
      .select({
        count: count(),
      })
      .from(campaigns)
      .where(
        userId 
          ? and(eq(campaigns.createdBy, userId), eq(campaigns.status, 'active'))
          : eq(campaigns.status, 'active')
      );

    // Get active influencers count (influencers in active collaborations)
    const [activeInfluencersResult] = await db
      .select({
        count: sql<number>`COUNT(DISTINCT ${collaborations.influencerId})::int`,
      })
      .from(collaborations)
      .innerJoin(campaigns, eq(collaborations.campaignId, campaigns.id))
      .where(
        userId 
          ? and(eq(campaigns.createdBy, userId), eq(collaborations.status, 'active'))
          : eq(collaborations.status, 'active')
      );

    return {
      totalReach: analyticsResult?.totalReach || 0,
      roi: analyticsResult?.avgRoi || "0.00",
      activeInfluencers: activeInfluencersResult?.count || 0,
      activeCampaigns: activeCampaignsResult?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
