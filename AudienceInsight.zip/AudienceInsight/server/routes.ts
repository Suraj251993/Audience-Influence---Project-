import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertInfluencerSchema, insertCampaignSchema, insertCollaborationSchema, insertCampaignAnalyticsSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard metrics
  app.get("/api/dashboard/metrics", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const metrics = await storage.getDashboardMetrics(userId);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Influencers routes
  app.get("/api/influencers", async (req, res) => {
    try {
      const {
        search,
        niche,
        minFollowers,
        maxFollowers,
        limit = "20",
        offset = "0",
      } = req.query;

      const params = {
        search: search as string,
        niche: niche as string,
        minFollowers: minFollowers ? parseInt(minFollowers as string) : undefined,
        maxFollowers: maxFollowers ? parseInt(maxFollowers as string) : undefined,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      };

      const influencers = await storage.getInfluencers(params);
      res.json(influencers);
    } catch (error) {
      console.error("Error fetching influencers:", error);
      res.status(500).json({ message: "Failed to fetch influencers" });
    }
  });

  app.get("/api/influencers/top-performers", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const topPerformers = await storage.getTopPerformingInfluencers(limit);
      res.json(topPerformers);
    } catch (error) {
      console.error("Error fetching top performers:", error);
      res.status(500).json({ message: "Failed to fetch top performers" });
    }
  });

  app.get("/api/influencers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const influencer = await storage.getInfluencer(id);
      
      if (!influencer) {
        return res.status(404).json({ message: "Influencer not found" });
      }
      
      res.json(influencer);
    } catch (error) {
      console.error("Error fetching influencer:", error);
      res.status(500).json({ message: "Failed to fetch influencer" });
    }
  });

  app.post("/api/influencers", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertInfluencerSchema.parse(req.body);
      const influencer = await storage.createInfluencer(validatedData);
      res.status(201).json(influencer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating influencer:", error);
      res.status(500).json({ message: "Failed to create influencer" });
    }
  });

  app.put("/api/influencers/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertInfluencerSchema.partial().parse(req.body);
      const influencer = await storage.updateInfluencer(id, validatedData);
      res.json(influencer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating influencer:", error);
      res.status(500).json({ message: "Failed to update influencer" });
    }
  });

  app.delete("/api/influencers/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteInfluencer(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting influencer:", error);
      res.status(500).json({ message: "Failed to delete influencer" });
    }
  });

  // Campaigns routes
  app.get("/api/campaigns", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const {
        status,
        limit = "20",
        offset = "0",
      } = req.query;

      const params = {
        status: status as string,
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      };

      const campaigns = await storage.getCampaigns(userId, params);
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.get("/api/campaigns/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const campaign = await storage.getCampaign(id);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      res.json(campaign);
    } catch (error) {
      console.error("Error fetching campaign:", error);
      res.status(500).json({ message: "Failed to fetch campaign" });
    }
  });

  app.post("/api/campaigns", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const validatedData = insertCampaignSchema.parse({
        ...req.body,
        createdBy: userId,
      });
      const campaign = await storage.createCampaign(validatedData);
      res.status(201).json(campaign);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating campaign:", error);
      res.status(500).json({ message: "Failed to create campaign" });
    }
  });

  app.put("/api/campaigns/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertCampaignSchema.partial().parse(req.body);
      const campaign = await storage.updateCampaign(id, validatedData);
      res.json(campaign);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating campaign:", error);
      res.status(500).json({ message: "Failed to update campaign" });
    }
  });

  app.delete("/api/campaigns/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCampaign(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting campaign:", error);
      res.status(500).json({ message: "Failed to delete campaign" });
    }
  });

  // Collaborations routes
  app.get("/api/collaborations", isAuthenticated, async (req, res) => {
    try {
      const { campaignId, influencerId } = req.query;
      const collaborations = await storage.getCollaborations(
        campaignId ? parseInt(campaignId as string) : undefined,
        influencerId ? parseInt(influencerId as string) : undefined
      );
      res.json(collaborations);
    } catch (error) {
      console.error("Error fetching collaborations:", error);
      res.status(500).json({ message: "Failed to fetch collaborations" });
    }
  });

  app.post("/api/collaborations", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertCollaborationSchema.parse(req.body);
      const collaboration = await storage.createCollaboration(validatedData);
      res.status(201).json(collaboration);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating collaboration:", error);
      res.status(500).json({ message: "Failed to create collaboration" });
    }
  });

  app.put("/api/collaborations/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertCollaborationSchema.partial().parse(req.body);
      const collaboration = await storage.updateCollaboration(id, validatedData);
      res.json(collaboration);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating collaboration:", error);
      res.status(500).json({ message: "Failed to update collaboration" });
    }
  });

  app.delete("/api/collaborations/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCollaboration(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting collaboration:", error);
      res.status(500).json({ message: "Failed to delete collaboration" });
    }
  });

  // Analytics routes
  app.get("/api/campaigns/:id/analytics", isAuthenticated, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const analytics = await storage.getCampaignAnalytics(campaignId);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching campaign analytics:", error);
      res.status(500).json({ message: "Failed to fetch campaign analytics" });
    }
  });

  app.post("/api/campaigns/:id/analytics", isAuthenticated, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const validatedData = insertCampaignAnalyticsSchema.parse({
        ...req.body,
        campaignId,
      });
      const analytics = await storage.createCampaignAnalytics(validatedData);
      res.status(201).json(analytics);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating campaign analytics:", error);
      res.status(500).json({ message: "Failed to create campaign analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
