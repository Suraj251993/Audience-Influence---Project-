import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  integer,
  decimal,
  boolean,
  serial,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("brand_manager"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Influencers table
export const influencers = pgTable("influencers", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  email: varchar("email").unique(),
  profileImageUrl: varchar("profile_image_url"),
  bio: text("bio"),
  niche: varchar("niche").notNull(),
  followers: integer("followers").notNull().default(0),
  engagementRate: decimal("engagement_rate", { precision: 5, scale: 2 }).notNull().default("0.00"),
  averagePostCost: decimal("average_post_cost", { precision: 10, scale: 2 }).notNull().default("0.00"),
  isVerified: boolean("is_verified").notNull().default(false),
  socialPlatforms: jsonb("social_platforms").default('{}'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Campaigns table
export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  budget: decimal("budget", { precision: 12, scale: 2 }).notNull(),
  status: varchar("status").notNull().default("planning"),
  category: varchar("category").notNull(),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  targetAudience: jsonb("target_audience").default('{}'),
  goals: jsonb("goals").default('{}'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Collaborations table (linking campaigns and influencers)
export const collaborations = pgTable("collaborations", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull().references(() => campaigns.id, { onDelete: "cascade" }),
  influencerId: integer("influencer_id").notNull().references(() => influencers.id, { onDelete: "cascade" }),
  status: varchar("status").notNull().default("pending"),
  agreedRate: decimal("agreed_rate", { precision: 10, scale: 2 }),
  deliverables: jsonb("deliverables").default('[]'),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Campaign analytics table
export const campaignAnalytics = pgTable("campaign_analytics", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull().references(() => campaigns.id, { onDelete: "cascade" }),
  totalReach: integer("total_reach").notNull().default(0),
  totalEngagements: integer("total_engagements").notNull().default(0),
  totalClicks: integer("total_clicks").notNull().default(0),
  totalConversions: integer("total_conversions").notNull().default(0),
  roi: decimal("roi", { precision: 8, scale: 2 }).notNull().default("0.00"),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  campaigns: many(campaigns),
}));

export const influencersRelations = relations(influencers, ({ many }) => ({
  collaborations: many(collaborations),
}));

export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  createdBy: one(users, {
    fields: [campaigns.createdBy],
    references: [users.id],
  }),
  collaborations: many(collaborations),
  analytics: many(campaignAnalytics),
}));

export const collaborationsRelations = relations(collaborations, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [collaborations.campaignId],
    references: [campaigns.id],
  }),
  influencer: one(influencers, {
    fields: [collaborations.influencerId],
    references: [influencers.id],
  }),
}));

export const campaignAnalyticsRelations = relations(campaignAnalytics, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [campaignAnalytics.campaignId],
    references: [campaigns.id],
  }),
}));

// Insert schemas
export const upsertUserSchema = createInsertSchema(users);
export const insertInfluencerSchema = createInsertSchema(influencers).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCampaignSchema = createInsertSchema(campaigns).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCollaborationSchema = createInsertSchema(collaborations).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCampaignAnalyticsSchema = createInsertSchema(campaignAnalytics).omit({ id: true });

// Types
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertInfluencer = z.infer<typeof insertInfluencerSchema>;
export type Influencer = typeof influencers.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;
export type InsertCollaboration = z.infer<typeof insertCollaborationSchema>;
export type Collaboration = typeof collaborations.$inferSelect;
export type InsertCampaignAnalytics = z.infer<typeof insertCampaignAnalyticsSchema>;
export type CampaignAnalytics = typeof campaignAnalytics.$inferSelect;
